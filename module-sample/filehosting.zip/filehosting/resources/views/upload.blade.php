@extends('layouts.admin')



@section('title', 'Upload File')

@section('main-content')
<div class="fh-container" x-data="fileUpload()" x-init="loadFolders()">

    <div class="fh-header">
        <div class="fh-header__left">
            <a href="{{ route('filehosting.index') }}" class="fh-back-link">
                <svg viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M9.707 16.707a1 1 0 01-1.414 0l-6-6a1 1 0 010-1.414l6-6a1 1 0 011.414 1.414L5.414 9H17a1 1 0 110 2H5.414l4.293 4.293a1 1 0 010 1.414z" clip-rule="evenodd"/></svg>
                Back
            </a>
            <h1 class="fh-page-title">Upload Files</h1>
        </div>
    </div>

    <div class="fh-upload-layout">

        {{-- ============================================================
             Drop Zone
        ============================================================ --}}
        <div class="fh-dropzone"
             @dragover.prevent="isDragging = true"
             @dragleave="isDragging = false"
             @drop.prevent="handleDrop($event)"
             :class="{ 'fh-dropzone--active': isDragging }">

            <input type="file" id="fileInput" multiple class="fh-dropzone__input"
                   @change="handleFiles($event.target.files)">

            <div class="fh-dropzone__icon">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"
                          d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12"/>
                </svg>
            </div>
            <p class="fh-dropzone__text">Drag & drop files here, or</p>
            <label for="fileInput" class="fh-btn fh-btn--primary" style="cursor:pointer">Browse Files</label>
            <p class="fh-dropzone__hint">Maximum file size: {{ ini_get('upload_max_filesize') }}</p>
        </div>

        {{-- ============================================================
             Upload Options
        ============================================================ --}}
        <div class="fh-upload-options">
            <div class="fh-form-group">
                <label class="fh-label">Destination Folder</label>
                <select x-model="folderId" class="fh-input">
                    <option value="">— Root (no folder) —</option>
                    <template x-for="f in folders" :key="f.id">
                        <option :value="f.id" x-text="f.path || f.name"></option>
                    </template>
                </select>
            </div>

            <div class="fh-form-group">
                <label class="fh-label">Visibility</label>
                <select x-model="visibility" class="fh-input">
                    <option value="private">Private</option>
                    <option value="public">Public</option>
                    <option value="restricted">Restricted</option>
                </select>
            </div>

            <div class="fh-form-group">
                <label class="fh-label">Description (optional)</label>
                <textarea x-model="description" rows="3" class="fh-input"
                          placeholder="Brief description for all uploaded files…"></textarea>
            </div>

            <div class="fh-form-group">
                <label class="fh-label">Expires At (optional)</label>
                <input type="datetime-local" x-model="expiresAt" class="fh-input">
            </div>
        </div>
    </div>

    {{-- ============================================================
         File Queue
    ============================================================ --}}
    <div class="fh-queue" x-show="queue.length > 0">
        <div class="fh-section-title">
            Queue (<span x-text="queue.length"></span> files)
            <button @click="uploadAll()" :disabled="uploading"
                    class="fh-btn fh-btn--primary fh-btn--sm" style="margin-left:auto">
                <span x-show="!uploading">Upload All</span>
                <span x-show="uploading">Uploading…</span>
            </button>
        </div>

        <ul class="fh-queue__list">
            <template x-for="(item, index) in queue" :key="index">
                <li class="fh-queue__item">
                    <div class="fh-queue__info">
                        <span class="fh-queue__name" x-text="item.file.name"></span>
                        <span class="fh-queue__size" x-text="formatBytes(item.file.size)"></span>
                    </div>
                    <div class="fh-queue__status">
                        <template x-if="item.status === 'pending'">
                            <span class="fh-badge fh-badge--gray">Pending</span>
                        </template>
                        <template x-if="item.status === 'uploading'">
                            <div class="fh-progress">
                                <div class="fh-progress__bar" :style="`width:${item.progress}%`"></div>
                            </div>
                        </template>
                        <template x-if="item.status === 'done'">
                            <span class="fh-badge fh-badge--green">✓ Done</span>
                        </template>
                        <template x-if="item.status === 'error'">
                            <span class="fh-badge fh-badge--red" :title="item.error">✗ Error</span>
                        </template>
                    </div>
                    <button @click="removeFromQueue(index)" x-show="item.status === 'pending'"
                            class="fh-queue__remove">&times;</button>
                </li>
            </template>
        </ul>
    </div>

    {{-- ============================================================
         Completed summary
    ============================================================ --}}
    <div class="fh-upload-done" x-show="doneCount > 0 && !uploading">
        <p><strong x-text="doneCount"></strong> file(s) uploaded successfully.</p>
        <a href="{{ route('filehosting.index') }}" class="fh-btn fh-btn--primary">Go to File Manager</a>
    </div>

</div>
@endsection

@push('styles')
@include('filehosting::_partials.styles')
@endpush

@push('scripts')
<script>
function fileUpload() {
    return {
        queue: [],
        folders: [],
        folderId: '',
        visibility: 'private',
        description: '',
        expiresAt: '',
        isDragging: false,
        uploading: false,
        doneCount: 0,

        async loadFolders() {
            const res = await fetch('{{ route('filehosting.folders.tree') }}', {
                headers: { 'Accept': 'application/json' }
            });
            const data = await res.json();
            this.folders = this.flattenTree(data);
        },

        flattenTree(nodes, prefix = '') {
            let flat = [];
            for (const n of nodes) {
                flat.push({ id: n.id, name: n.name, path: prefix + n.name });
                if (n.children?.length) {
                    flat = flat.concat(this.flattenTree(n.children, prefix + n.name + ' / '));
                }
            }
            return flat;
        },

        handleFiles(fileList) {
            for (const f of fileList) {
                this.queue.push({ file: f, status: 'pending', progress: 0, error: '' });
            }
        },

        handleDrop(event) {
            this.isDragging = false;
            this.handleFiles(event.dataTransfer.files);
        },

        removeFromQueue(index) {
            this.queue.splice(index, 1);
        },

        async uploadAll() {
            this.uploading = true;
            for (const item of this.queue) {
                if (item.status !== 'pending') continue;
                await this.uploadItem(item);
            }
            this.uploading = false;
            this.doneCount = this.queue.filter(i => i.status === 'done').length;
        },

        async uploadItem(item) {
            item.status = 'uploading';
            const fd = new FormData();
            fd.append('file', item.file);
            if (this.folderId)    fd.append('folder_id', this.folderId);
            if (this.description) fd.append('description', this.description);
            if (this.expiresAt)   fd.append('expires_at', this.expiresAt);
            fd.append('visibility', this.visibility);
            fd.append('_token', document.querySelector('meta[name=csrf-token]').content);

            return new Promise((resolve) => {
                const xhr = new XMLHttpRequest();
                xhr.open('POST', '{{ route('filehosting.files.store') }}');
                xhr.setRequestHeader('Accept', 'application/json');

                xhr.upload.onprogress = (e) => {
                    if (e.lengthComputable) item.progress = Math.round((e.loaded / e.total) * 100);
                };

                xhr.onload = () => {
                    if (xhr.status === 201) {
                        item.status = 'done'; item.progress = 100;
                    } else {
                        item.status = 'error';
                        try { item.error = JSON.parse(xhr.responseText).message || 'Upload failed'; }
                        catch { item.error = 'Upload failed'; }
                    }
                    resolve();
                };

                xhr.onerror = () => { item.status = 'error'; item.error = 'Network error'; resolve(); };
                xhr.send(fd);
            });
        },

        formatBytes(bytes) {
            if (bytes < 1024) return bytes + ' B';
            if (bytes < 1048576) return (bytes / 1024).toFixed(1) + ' KB';
            return (bytes / 1048576).toFixed(1) + ' MB';
        },
    };
}
</script>
@endpush
