<?php
namespace App\Modules\FileHosting\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use App\Modules\FileHosting\Services\FileHostingService;
use App\Modules\FileHosting\Models\File;

class FileHostingController extends Controller
{
    protected FileHostingService $service;

    public function __construct(FileHostingService $service)
    {
        $this->service = $service;
    }

    /** Dashboard: list files */
    public function index()
    {
        $files = File::all();
        return view('filehosting::index', compact('files'));
    }

    /** Show upload form */
    public function showUploadForm()
    {
        $files = File::all();
        return view('filehosting::upload', compact('files'));
    }

    /** Handle file upload */
    public function upload(Request $request)
    {
        $request->validate([
            'file' => 'required|file|max:10240', // 10MB max
        ]);

        // ✅ Ensure folder exists first
        $folder = 'filehosting/files';
        if (!Storage::disk('public')->exists($folder)) {
            Storage::disk('public')->makeDirectory($folder, 0755, true);
        }

        // Upload the file
        $this->service->uploadFile($request->file('file'), auth()->id());

        return redirect()
            ->route('filehosting.upload')
            ->with('success', 'File uploaded successfully!');
    }

    /** View / open file */
/** View / open file safely */
public function view(File $file)
{
    // Use stored_name if available, fallback to path basename
    $fileName = $file->stored_name ?: basename($file->path);

    // Relative path on the "public" disk
    $relativePath = 'filehosting/files/' . $fileName;

    // Check if the file exists on the public disk
    if (!Storage::disk('public')->exists($relativePath)) {
        abort(404, "File '{$file->name}' not found on server.");
    }

    // Get full absolute path (resolves public/storage symlink)
    $fullPath = Storage::disk('public')->path($relativePath);

    // Return file inline for browser viewing
    return response()->file($fullPath, [
        'Content-Disposition' => 'inline; filename="' . $file->name . '"',
    ]);
}

    /** Delete file */
    public function delete(File $file)
    {
        $this->service->deleteFile($file);
        return redirect()->back()->with('success', 'File deleted successfully!');
    }
}
