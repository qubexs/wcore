<!-- index blade -->

@extends('layouts.admin')

@section('main-content')
<h1 class="mb-4">File Hosting</h1>

<!-- Upload Form -->
<form action="{{ route('filehosting.upload') }}" method="POST" enctype="multipart/form-data" class="mb-4 d-flex gap-2 align-items-center">
    @csrf
    <input type="file" name="file" required class="form-control">
    <button type="submit" class="btn btn-primary">
        <i class="fas fa-upload me-1"></i> Upload
    </button>
</form>

<!-- Success / Error Messages -->
@if(session('success'))
    <div class="alert alert-success">{{ session('success') }}</div>
@endif
@if(session('error'))
    <div class="alert alert-danger">{{ session('error') }}</div>
@endif

<!-- File Table -->
<table class="table table-bordered table-striped align-middle">
    <thead class="table-dark">
        <tr>
            <th>File</th>
            <th>Thumbnail</th>
            <th>Uploaded By</th>
            <th>Uploaded At</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        @forelse($files as $file)
            <tr>
                <!-- File Name & Link -->
                <td>
                    <a href="{{ Storage::url($file->path) }}" target="_blank">
                        {{ $file->name }}
                    </a>
                </td>

                <!-- Thumbnail -->
                <td>
                    @if($file->thumbnail)
                        <img src="{{ Storage::url($file->thumbnail) }}" width="50" class="img-thumbnail">
                    @else
                        <span class="text-muted">N/A</span>
                    @endif
                </td>

                <!-- Uploaded By -->
                <td>{{ optional($file->uploader)->name ?? $file->uploaded_by }}</td>

                <!-- Uploaded At -->
                <td>{{ $file->created_at->format('d M Y, H:i') }}</td>

                <!-- Actions -->
                <td class="d-flex gap-1">
                    <!-- Download -->
                    <a href="{{ route('filehosting.download', $file) }}" class="btn btn-success btn-sm" title="Download">
                        <i class="fas fa-download"></i>
                    </a>

                    <!-- Delete -->
                    <form action="{{ route('filehosting.delete', $file) }}" method="POST" onsubmit="return confirm('Delete file?')">
                        @csrf
                        @method('DELETE')
                        <button class="btn btn-danger btn-sm" title="Delete">
                            <i class="fas fa-trash-alt"></i>
                        </button>
                    </form>
                </td>
            </tr>
        @empty
            <tr>
                <td colspan="5" class="text-center text-muted">No files uploaded yet.</td>
            </tr>
        @endforelse
    </tbody>
</table>
@endsection
